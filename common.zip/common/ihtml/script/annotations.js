
var annotation; //current bubble

function Annotation() {
	Balloon.call(this);
}

Annotation.prototype = new Balloon();
Annotation.prototype.doShowTooltip = function() {
	Balloon.prototype.doShowTooltip.call(this);
	//and set focus to textarea if it exists
	var balloonContents = document.getElementById('contentWrapper');
	var inp = balloonContents.getElementsByTagName("textarea");
	if (inp && inp.length > 0) {
		inp[0].focus();
	}
//the actual balloon is div element with id = visibleBalloonElement
//referenced by currentBalloonClass.contents
//close button is an image element id=closeButton whose parent is the document.body
}

function initAnnotations() {
	// a plainer popup box
	annotation         = new Annotation;//Balloon;//Box;
	BalloonConfig(annotation,'GBubble');
	annotation.allowEventHandlers = true;
	annotation.allowFade = true;
}

function isAnnotationVisible() {
	return balloonIsVisible ? "1" : "";
}

/*html annotations events handling */

var contentStyle = 
'<style type="text/css"> div#contentWrapper, textarea {border: none;font-style:normal;font-family:  Arial, Verdana, Geneva, Helvetica;font-size: 18px;color:rgb(0,0,0);}</style>';
var editedMsgs = new Array();
var currentMsgId;
var currentMsg;
var currentEvt;
var defaultMsg = "Tap here to edit your annotation    ";
//TODO make all this part of the 'object' Annotation

function fetchNClearAnnotations() {
	var ret = '';
	var delim = '@#';
	for (var msgId in editedMsgs) {
		ret += delim + '0x' + decimalToHex(msgId,8) + escape(editedMsgs[msgId]);
	}
	editedMsgs = [];
	return ret;
}

function swapField(balloon) {
	var m;
	var ms;
	var width = balloon.contents.lastChild.offsetWidth;
	var height = balloon.contents.lastChild.offsetHeight;
	if (balloon.container.innerHTML.substring(0,"<span".length) == "<span") {
		ms = currentMsg == defaultMsg ? '' : currentMsg;
		var size = currentMsg.length;
		var w = size * avFontPixelSize.width;
		var rows = Math.round(w/width + 0.5);
		size = Math.round(size/rows + 0.5) + 10;//account for word wrapping
		width = size * avFontPixelSize.width + 10; //account for a scroll a bit
		height = Math.max(Math.max(height,50),rows * avFontPixelSize.height) + balloon.padding + balloon.shadow + 10;//in case of scroll
		m = 
'<textarea onKeyUp="maybeSaveText(event,annotation)" onBlur="maybeSaveText(event,annotation)" onFocus="onFocusEvt(event)" cols='+ size + ' rows=' + rows + '>';
		m += ms;
		m += '</textarea>';
	} else {
		ms = currentMsg;
		width = Math.max(200,ms.length * avFontPixelSize.width);
		m = '<span onClick="swapField(annotation)">' + ms + "</span>";
	}
	m += contentStyle;
	balloon.hideTooltip(true); //hide sticky balloon
	balloon.allowFade = false;
	balloon.showTooltip(currentEvt,m,false,width,height);
}

function onFocusEvt(event) {
	event.currentTarget.select();
}

function getTextArea() {
	var balloonContents = document.getElementById('contentWrapper');
	var ret;
	if (balloonContents) {
		var inp = balloonContents.getElementsByTagName("textarea");
		if (inp && inp.length > 0) {
			ret = inp[0];
		}
	}
	return ret;
}

function selectAnnotationText() {
	var txt = getTextArea();
	if (txt) {
		txt.select();
	}
}

function storeMsg() {
	var txt = getTextArea();
	if (txt && currentMsg != txt.value && txt.value.replace(/\s*$/, "") != '') {
		currentMsg = editedMsgs[currentMsgId] = txt.value;
		var trg = currentEvt.currentTarget ? currentEvt.currentTarget : currentEvt.target;
		//debugOut(enumMemberVars(currentEvt,1));
		trg.src = "../../images/balloons/pencil_ic.png";
	}
}

function showMsg(msg) {
	var txt = getTextArea();
	if (txt) {
		txt.value += msg;
	}
}

function maybeSaveText(event,balloon) {
	//showMsg(event.type);
	if (event.type == "keyup") {
		switch (event.keyCode) {
			//case 13:
			case 14: {
			//save text
				storeMsg();
				break;
			}
			case 27:
				balloon.hideTooltip(true); //hide sticky balloon
				break;
		}
	} else {
	//save text
		storeMsg();
	}
}

function onC(event,msgId,msg,ro) {
	initFontPixelSize();
	currentMsgId = msgId;
	var readOnly = typeof(ro) != 'undefined' && ro;
	var ms = unescape(editedMsgs[msgId] ? editedMsgs[msgId] : (readOnly ? (msg || 'No note') : (msg || defaultMsg)));
	currentMsg = ms;
	var m = (ro ? '<span>' : '<span onClick="swapField(annotation)">') + ms + "</span>" + contentStyle;
	currentEvt = event;
	var size = Math.max(ms.length,28);
	var width = Math.max(200,size * avFontPixelSize.width);
	annotation.allowFade = true;
	annotation.showTooltip(event,m,false,width);
}

