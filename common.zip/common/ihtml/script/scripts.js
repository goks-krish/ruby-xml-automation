/*************************************************************************
	 *
	 * Copyright (c) 2005+ MedHand International AB
	 * All rights reservered.
	 *
	 ***************************************************************
	 *
	 * @(#)script.js
   *
   * DESCRIPTION:
   * ======================
   * scripts for handling pop-up footnotes, expandable sections and annotation&highlight 
   *
   * CHANGES:
   * ======================
   * 2011-11-25 modified last soft-link logic, added (el.nextSibling.className != "soft-state")
	 *************************************************************************/

/* some helpers */
String.prototype.format = function() {
  var args = arguments;
  return this.replace(/{(\d+)}/g, function(match, number) { 
    return typeof args[number] != 'undefined'
      ? args[number]
      : match
    ;
  });
};

function measureText(pText, pFontSize, pStyle) {
    var lDiv = document.createElement('lDiv');

    document.body.appendChild(lDiv);

    if (pStyle != null) {
        lDiv.style = pStyle;
    }
    lDiv.style.fontSize = "" + pFontSize + "px";
	lDiv.style.fontFamily = "Arial, Verdana, Geneva, Helvetica";
    lDiv.style.position = "absolute";
    lDiv.style.left = -1000;
    lDiv.style.top = -1000;

    lDiv.innerHTML = pText;

    var lResult = {
        width: lDiv.clientWidth,
        height: lDiv.clientHeight
    };

    document.body.removeChild(lDiv);
    lDiv = null;

    return lResult;
}

function decimalToHex(d, padding) {
    var hex = Number(d).toString(16).toUpperCase();
    padding = typeof (padding) === "undefined" || padding === null ? padding = 2 : padding;

    while (hex.length < padding) {
        hex = "0" + hex;
    }

    return hex;
}

var avFontPixelSize;
function initFontPixelSize() {
	if (!avFontPixelSize) {
		var t = "ABMYabmyWwcD";
		avFontPixelSize = measureText("ABMYabmyWwcD",18); //assumeing 18px font
		avFontPixelSize.width = Math.round(avFontPixelSize.width/t.length);
	}
}

function isSafari(){
	return navigator.userAgent.toLowerCase().indexOf( 'applewebkit' ) != -1;
}

function isMobileSafari(){
	return isSafari() && navigator.userAgent.toLowerCase().indexOf( 'mobile' ) != -1;
}

function init() {
	initAnnotations();
}

function enableRemoveAllHighlights() {
	return isAnnotationVisible() ? "" : (document.getElementById("s876") ? "H" : "" ); 
}

function getPlainHTML() {
	return "<html>" + document.firstChild.innerHTML + "</html>";
}

/* selection (copied from selection.js until we've amended book creation to include selction.js as well*/
/* selections*/
function skipAdjancedTags(element,tagRegex, offset) {
	while (true) {
		var s = element.innerHTML.substring(offset);
		var m = s.match(tagRegex);
		if (m && m.index == 0) {
			offset += m[0].length;
		} else {
			break;
		}
	}
	return offset;
}

function sumInnerHTMLs(element,upToChild) {
	var tagRegex = new RegExp("<[^\\(\\);<> ]+[^>]*>");
	var offset = 0;
	var children = element.childNodes;
	for(var n=0; n < children.length; n++) {
		var pos = 0;
		var txt = "";
		var chld = children[n];
		if (chld.nodeType == 3) {
			//got text element =>skip all tags until we find it
			while (true) {
				offset = skipAdjancedTags(element, tagRegex, offset);
				txt = chld.nodeValue;
				var s = element.innerHTML.substring(offset);
				pos = s.indexOf(txt);
				if (pos > 0) {
				//check for any tags infront of it
					var m = s.match(tagRegex);
					if (m && m.index < pos) {
						offset += (m.index + m[0].length);
					} else {
						break;
					}
				} else {
					break;
				}
			}
		} else {
			//find the current node tag
			var nam = "<" + chld.nodeName.toLowerCase();
			while (true) {
				var s = element.innerHTML.substring(offset);
				var m = s.match(tagRegex);
				if (m) {
					offset += (m.index + m[0].length);
				}
				if (chld == upToChild) {
					break;
				}
				if (!m || m[0].substring(0, nam.length).toLowerCase() == nam) {
					offset += chld.innerHTML.length;
					s = element.innerHTML.substring(offset);
					nam = "</" + chld.nodeName.toLowerCase() + ">";
					pos = s.toLowerCase().indexOf(nam);
					if (pos == 0) {
						offset += nam.length;
					}
					pos = 0;
					break;
				}
			}
		}
		offset += pos;
		if (chld == upToChild) {
			break;
		}
		offset += txt.length;
	}
	return offset;
}

function anchorSelection(sel,startOffset) {
	var ret = '';
	//prefix the selection with the offset within html tag in case we got a short selection that could
	//potentially repeate within HTML
	var delim = "@#0x";
	var parent = sel.anchorNode.parentNode;
	var child = sel.anchorNode;
	var selOffset = startOffset;
	while (parent && parent.innerHTML) {
		selOffset += sumInnerHTMLs(parent, child);
		child = parent;
		parent = parent.parentNode;
	}
	//debugOut += child.innerHTML.substring(selOffset,selOffset + 20);
	//debugLog(debugOut);
	selOffset += "<html>".length; //the very top level last tag length isn't included
	ret = selOffset + delim;
	return ret;
}

function getInnerText(container) {
	var text = '';
	if (container.childNodes) {
		var children = container.childNodes;
		for(var n=0; n < children.length; n++) {	
			var chld = children[n];
			text += getInnerText(chld);
			if (chld.nodeType == 3) {
				text += chld.nodeValue;
			}
		}
	}
	if (container.nodeType == 3) {
		text += container.nodeValue;
	}
	return text;
}

function cleanupMess(html) {
//this doesn't really work for mozzila since it formats text differently in each node so that innerHTML of individual nodes
//cannot be found in the document.firstChild.innerHTML - what a mess!
	if (document.firstChild.innerHTML.indexOf(html) < 0) {
		var closeTagRegex = new RegExp("</[^\\(\\);<> ]+>$");
		var m = html.match(closeTagRegex);
		var m1;
		while (m) {
			m1 = html.substring(0, m.index).match(closeTagRegex);
			if (!m1) {
				m1 = m;
				break;
			}
			html = html.substring(0, m.index);
			if (document.firstChild.innerHTML.indexOf(html) >= 0) {
				return html;
			}
			m = m1;
		}
		var tagRegex = new RegExp("^<[^\\(\\);<> ]+[^<>]*>");
		while (document.firstChild.innerHTML.indexOf(html) < 0) {
			m = html.match(tagRegex);
			if (!m) {
				if (m1) {//remove the last remaining leading tag
					html = html.substring(0, m1.index);
					if (document.firstChild.innerHTML.indexOf(html) < 0) {
						html = ""; //we'r shafted
					}
				}
				break;
			}
			html = html.substring(m.index + m[0].length);
		}
	}
	return html;
}

function getHtmlSelection() {
    var html = "";
	debugOut = "";
    if (typeof window.getSelection != "undefined") {
        var sel = window.getSelection();
        if (sel.rangeCount) {
            var container = document.createElement("div");
            var range0 = sel.getRangeAt(0);
            for (var i = 0, len = sel.rangeCount; i < len; ++i) {
                container.appendChild(sel.getRangeAt(i).cloneContents());
            }

			if (container.lastChild != container.firstChild) {
//				debugLog("container.lastChild != container.firstChild");
//				debugOut += getInnerText(container.lastChild);
				if (container.lastChild && getInnerText(container.lastChild).length == 0) {
					container.removeChild(container.lastChild);
				}
			}
			html = cleanupMess(container.innerHTML);
			if (html.length > 0 && html.length < 24) {
				html = anchorSelection(sel,range0.startOffset) + html;
			}
        }
    } else if (typeof document.selection != "undefined") {
        if (document.selection.type == "Text") {
            html = document.selection.createRange().htmlText;
        }
    }
    return html;
}

function maybeGetHtmlSelection() {
	if (typeof window.isAnnotationVisible != "undefined") {
		return isAnnotationVisible() ? "" : getHtmlSelection();
	}
	return getHtmlSelection();
}

/* Footnotes */

function showObject(e, obj) {
	closeFootnotes();
	
	if (e.clientX < (window.innerWidth / 2)) {
	    if((e.clientX + document.getElementById(obj).offsetWidth + 10) > (window.innerWidth - 10))
	    	document.getElementById(obj).style.left =  window.innerWidth - document.getElementById(obj).offsetWidth - 10;
	    else
	    	document.getElementById(obj).style.left =  e.clientX + 10;
	}
	else {
	 	if((e.clientX - document.getElementById(obj).offsetWidth - 10) < 10)
	    	document.getElementById(obj).style.left = 10;
	    else
	    	document.getElementById(obj).style.left =  e.clientX - document.getElementById(obj).offsetWidth - 10;;
	}
	
	// Get the mouse coordinates relative to the document top
	var posx = 0;
	var posy = 0;
	if (!e) var e = window.event;
	if (e.pageX || e.pageY) 	{
		posx = e.pageX;
		posy = e.pageY;
	}
	else if (e.clientX || e.clientY) 	{
		posx = e.clientX + document.body.scrollLeft
			+ document.documentElement.scrollLeft;
		posy = e.clientY + document.body.scrollTop
			+ document.documentElement.scrollTop;
	}
	// posx and posy contain the mouse position relative to the document
	  
	document.getElementById(obj).style.top = posy + 10;
	/*document.getElementById(obj).style.top = e.clientY + 10;*/
	  
	document.getElementById(obj).style.backgroundColor = "80ffff";
	document.getElementById(obj).style.visibility = "visible";
}

function hideObject(obj) {
 
	document.getElementById(obj).style.visibility = "hidden"; 
}

function closeFootnotes()
{
	var x = document.getElementsByTagName('span');
	for (var i=0;i<x.length;i++)
	{
		if (x[i].className == 'footnote' && x[i].style.visibility == 'visible')
		{
			 x[i].style.visibility = "hidden";

		}
	}
}

function closeFootnote(event, obj)
{	
	if (obj.className == 'footnote' && obj.style.visibility == 'visible')
	{
		obj.style.visibility = "hidden";
	}
	
	/*alert(event.type + ' ' + obj.nodeName + ' ' + obj.lastChild.nodeName + ' ' + obj.childElementCount);*/
	if (obj.nodeName == 'SPAN')
	{
		return false;
	}
	event.cancelBubble = true;
	if (event.stopPropagation) event.stopPropagation();
	return true;
}

function center()
{
	var x = document.getElementsByTagName('span');
	for (var i=0;i<x.length;i++)
	{
		if (x[i].className == 'footnote' && x[i].style.visibility == 'visible')
		{
			 x[i].style.left = document.body.offsetWidth/2 - 110;;
		}
	}
}

/* Soft containers */

window.onload=initilizeSoftContainers;

function initilizeSoftContainers(){
	var elements;
	if(document.all)
		elements=document.all;
	else
		elements = document.getElementsByTagName("*");
	softContentCollection=getElements(elements, "soft-content");
	softStateCollection=getElements(elements, "soft-state");
}


function changeStateForAnchorLink(anchor){
	var el = document.getElementById(anchor);
	var parent = el.parentNode;
	while (parent != null) {
		if (parent.className == "soft-content") {
			changeState(parent.id, 'block');
		}
		parent = parent.parentNode;
	}
	if (el.className == "soft-content"){
		changeState(el.id, 'block');
	}
}

function changeState(id,state){
	
	if (softContentCollection.length>0){
		var path = document.location.pathname.substring(0,document.location.pathname.lastIndexOf('/'));
		var parent_directory = path.substring(path.lastIndexOf('/') + 1);
		
		var dstate = state ? state : "block";
		var el = document.getElementById(id);
		if(el.style.display!=dstate){
			
			if(document.body.className == "iphone-style"){
				el.previousSibling.firstChild.style.WebkitBorderBottomLeftRadius = '0px';
				el.previousSibling.firstChild.style.WebkitBorderBottomRightRadius = '0px';
				
				if(parent_directory == "html"){
					el.previousSibling.firstChild.style.backgroundImage = 'url(../css/arrow-up.png)';
				}
				else{
					el.previousSibling.firstChild.style.backgroundImage = 'url(../../css/arrow-up.png)';
				}
				
				if(el.nextSibling == null || el.nextSibling.className != "soft-state"){
					el.style.WebkitBorderBottomLeftRadius = '8px';
					el.style.WebkitBorderBottomRightRadius = '8px';
				}
			}
			el.style.display = dstate;
		}
		else if (!state) {
	
			if(document.body.className == "iphone-style"){
				if(el.nextSibling == null || el.nextSibling.className != "soft-state"){
					el.previousSibling.firstChild.style.WebkitBorderBottomLeftRadius = '8px';
					el.previousSibling.firstChild.style.WebkitBorderBottomRightRadius = '8px';
				}
				
				if(parent_directory == "html"){
					el.previousSibling.firstChild.style.backgroundImage = 'url(../css/arrow-down.png)';
				}
				else{
					el.previousSibling.firstChild.style.backgroundImage = 'url(../../css/arrow-down.png)';
				}
				
			}
			el.style.display = "none";
		}
	}
	updateState()
}

function updateState(){
	var i=0;
	while (softStateCollection[i]){
		if (softContentCollection[i].style.display=="block")
			softStateCollection[i].innerHTML='-';
		else
			softStateCollection[i].innerHTML='+';
		i++
	}
}

function getElements(root, elementClass){
	var array=new Array();
	var a=0;
	var length=root.length;
	for (i=0; i<length; i++){
		if (root[i].className==elementClass)
			array[a++]=root[i];
	}
	return array;
}





